# AI Moderation Task - Python

## Features

-   Takes dynamic user input
-   Adds system prompt
-   Calls OpenAI API
-   Input moderation (blocks harmful content)
-   Output moderation (redacts unsafe text)

## How to Run

1.  Install dependencies: pip install -r requirements.txt

2.  Add your OpenAI API key in main.py

3.  Run script: python main.py

## Moderation Rules

-   Blocks: kill, hack, bomb, terror, attack
-   Replaces any of these words in output with \[REDACTED\]
